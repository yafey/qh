---
title: 群晖通过 Dockerfile 构建
tags:
  - Docker
  - Synology
  - 群晖
categories: Docker
typora-copy-images-to: 2022-synology-dockerfile-build
typora-root-url: 2022-synology-dockerfile-build
date: '2022-10-4 00:11:54'
comments: true
---

群晖通过 Dockerfile 构建。  
<!-- more -->



# 群晖通过Dockerfile构建 Image[^synology-dockerfile-csdn]

然后通过ssh连接群晖，登录root用户

cd到docker目录(cd /docker)  ---- Dockerfile 存放目录

构建自己的docker镜像( **`sudo docker build -t tomcat-heardfate .`** )  **// 这里必须要用 sudo，要不然没有权限**

接着 ，去群晖的docker——>映象 就会多出 tomcat-heardfate

![群晖Docker](/Center.jpeg)

[^synology-dockerfile-csdn]: [群晖Docker通过Dockerfile构建镜像 部署Tomcat](https://blog.csdn.net/heardy/article/details/73733731)  | [@archive.org](https://web.archive.org/web/20221003160438/https://blog.csdn.net/heardy/article/details/73733731#)





#  push Dockerfile 到docker-hub[^push-dockerfile]

## 根据 Dockerfile build 并测试

The docker build command processes this file generating a Docker Image in your Local Image Cache, which you can then start-up using the docker run command, or push to a permanent Image Repository.

docker build 创建一个docker镜像，这个镜像可以在你本地运行。

```shell
docker build -t mytomcat:1.0 .  # 注意最后的 '.' ,代表当前目录（Dockerfile 所在的目录）。
docker run -p 8080:8080 -d mytomcat:1.0
curl localhost:8080
```

## push 到 docker hub

第一步：修改 tag 名称

```shell
# 必须先修改 tag 名称
docker tag firstimage YOUR_DOCKERHUB_NAME/firstimage

# 举例： docker tag mytomcat:1.0 preparedman/mytomcat:1.0
```

第二步：push

```shell
docker push YOUR_DOCKERHUB_NAME/firstimage

# 举例：docker push preparedman/mytomcat:1.0
```

Docker 测试

```javascript
https://cloud.docker.com/u/preparedman/repository/docker/preparedman/mytomcat
```

[https://stackoverflow.com/que...](https://stackoverflow.com/questions/39508018/docker-driver-failed-programming-external-connectivity-on-endpoint-webserver)



[^push-dockerfile]: [【docker】创建Dockerfile并push到docker-hub](https://cloud.tencent.com/developer/article/1518323) | [@archive.org](https://web.archive.org/web/20221003161847/https://cloud.tencent.com/developer/article/1518323)